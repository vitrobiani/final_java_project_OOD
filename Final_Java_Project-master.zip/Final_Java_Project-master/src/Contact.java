public class Contact extends Person{
    public Contact(String name, String phoneNumber){
        super(name, phoneNumber);
    }
}
