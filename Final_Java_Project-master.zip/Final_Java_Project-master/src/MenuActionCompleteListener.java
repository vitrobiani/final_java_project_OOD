public abstract class MenuActionCompleteListener {
    public void update(String str){
        System.out.println(str);
    }
}
