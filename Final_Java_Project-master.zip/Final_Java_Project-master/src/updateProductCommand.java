public class updateProductCommand extends MenuActionCompleteListener implements Command{
    @Override
    public boolean execute() {
        return false;
    }
}
