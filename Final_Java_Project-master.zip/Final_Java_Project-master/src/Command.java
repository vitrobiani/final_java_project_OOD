import java.io.IOException;

public interface Command {
    public boolean execute();
}
